======================================================
Oracle Free Use Terms and Conditions (FUTC) License 
======================================================
https://www.oracle.com/downloads/licenses/oracle-free-license.html
===================================================================

ojdbc10-full.tar.gz - JDBC Thin Driver and Companion JARS
========================================================
This TAR archive (ojdbc10-full.tar.gz) contains the 19.10 release of the Oracle JDBC Thin driver(ojdbc10.jar), the Universal Connection Pool (ucp.jar) and other companion JARs grouped by category. 

(1) ojdbc10.jar (4,442,335 bytes) -
(SHA1 Checksum: 4174e8d8acc29676b9d0784a61138408da7f626b)
Oracle JDBC Driver compatible with JDK10 and JDK11;
(2) ucp.jar (1,688,939 bytes) - (SHA1 Checksum: b61480d68481872ce870537d1ce2ac2e33dc38da)
Universal Connection Pool classes for use with JDK8, JDK9, and JDK11 -- for performance, scalability, high availability, sharded and multitenant databases.
(3) ojdbc.policy (11,515 bytes) - Sample security policy file for Oracle Database JDBC drivers

======================
Security Related JARs
======================
Java applications require some additional jars to use Oracle Wallets. 
You need to use all the three jars while using Oracle Wallets. 

(4) oraclepki.jar (305,621 bytes) - (SHA1 Checksum: af1089da8269faebaff81f2586520ef916abaf0b)
Additional jar required to access Oracle Wallets from Java
(5) osdt_cert.jar (210,336 bytes) - (SHA1 Checksum: 525af7f07e74b169d866c2cae8160a03d8614337)
Additional jar required to access Oracle Wallets from Java
(6) osdt_core.jar (312,199 bytes) - (SHA1 Checksum: 4b370e713f1135e1c322cca4670542275956f466)
Additional jar required to access Oracle Wallets from Java

=============================
JARs for NLS and XDK support 
=============================
(7) orai18n.jar (1,663,954 bytes) - (SHA1 Checksum: 53d67daca370271d1ec333b4c82cf0add9a0831b) 
Classes for NLS support
(8) xdb.jar (265,580 bytes) - (SHA1 Checksum: ea875a84d8f78ab8aafb51ed50aa8f9b0d7b2b21)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
(9) xmlparserv2.jar (1,935,477 bytes) - (SHA1 Checksum: fb65e103debdb23adef2a483c00d34bc60ef242b)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
====================================================
JARs for Real Application Clusters(RAC), ADG, or DG 
====================================================
(10) ons.jar (156,242 bytes) - (SHA1 Checksum: 6e79450393c284ebc06dd164d73a37eb91c1165f)
for use by the pure Java client-side Oracle Notification Services (ONS) daemon
(11) simplefan.jar (32,167 bytes) - (SHA1 Checksum: 843b32e3d3bc9d3cfafbb2d701f67985f6227f7d)
Java APIs for subscribing to RAC events via ONS; simplefan policy and javadoc

=================
USAGE GUIDELINES
=================
Refer to the JDBC Developers Guide (https://docs.oracle.com/en/database/oracle/oracle-database/19/jjdbc/index.html) and Universal Connection Pool Developers Guide (https://docs.oracle.com/en/database/oracle/oracle-database/19/jjucp/index.html)for more details. 
